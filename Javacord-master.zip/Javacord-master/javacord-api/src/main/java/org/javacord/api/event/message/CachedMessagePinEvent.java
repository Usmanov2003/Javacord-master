package org.javacord.api.event.message;

/**
 * A cached message pin event.
 */
public interface CachedMessagePinEvent extends CertainMessageEvent {
}
