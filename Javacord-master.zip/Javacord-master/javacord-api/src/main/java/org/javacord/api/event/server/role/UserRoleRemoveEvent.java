package org.javacord.api.event.server.role;

/**
 * A user role remove event.
 */
public interface UserRoleRemoveEvent extends UserRoleEvent {
}
