package org.javacord.api.event.server.role;

import org.javacord.api.event.user.UserEvent;

/**
 * A user role event.
 */
public interface UserRoleEvent extends RoleEvent, UserEvent {
}
