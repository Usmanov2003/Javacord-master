package org.javacord.api.event.channel.server;

/**
 * A server channel create event.
 */
public interface ServerChannelCreateEvent extends ServerChannelEvent {
}
