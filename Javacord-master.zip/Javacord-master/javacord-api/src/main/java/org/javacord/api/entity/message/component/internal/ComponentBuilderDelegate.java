package org.javacord.api.entity.message.component.internal;

public interface ComponentBuilderDelegate { }
