package org.javacord.api.event.message;

/**
 * A cached message unpin event.
 */
public interface CachedMessageUnpinEvent extends CertainMessageEvent {
}
