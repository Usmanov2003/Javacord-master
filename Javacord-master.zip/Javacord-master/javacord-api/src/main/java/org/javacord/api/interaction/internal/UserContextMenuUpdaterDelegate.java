package org.javacord.api.interaction.internal;

import org.javacord.api.interaction.UserContextMenu;

public interface UserContextMenuUpdaterDelegate extends ApplicationCommandUpdaterDelegate<UserContextMenu> {
}
