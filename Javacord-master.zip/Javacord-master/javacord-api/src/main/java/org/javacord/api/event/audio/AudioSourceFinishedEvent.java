package org.javacord.api.event.audio;

/**
 * An audio source finished event.
 */
public interface AudioSourceFinishedEvent extends AudioSourceEvent {

}
