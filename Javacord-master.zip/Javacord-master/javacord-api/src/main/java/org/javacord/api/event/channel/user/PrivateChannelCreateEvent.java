package org.javacord.api.event.channel.user;

/**
 * A private channel create event.
 */
public interface PrivateChannelCreateEvent extends PrivateChannelEvent {
}
