package org.javacord.api.event.message.reaction;

import org.javacord.api.event.message.RequestableMessageEvent;

/**
 * A reaction event.
 */
public interface ReactionEvent extends RequestableMessageEvent {
}
