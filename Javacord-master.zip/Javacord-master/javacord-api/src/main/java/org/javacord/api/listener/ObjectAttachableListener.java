package org.javacord.api.listener;

/**
 * This is a marker interface for listeners that can be attached to an object.
 */
public interface ObjectAttachableListener {
}
