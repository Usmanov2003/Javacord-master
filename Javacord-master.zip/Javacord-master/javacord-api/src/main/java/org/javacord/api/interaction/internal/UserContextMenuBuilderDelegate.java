package org.javacord.api.interaction.internal;

import org.javacord.api.interaction.UserContextMenu;

public interface UserContextMenuBuilderDelegate extends ApplicationCommandBuilderDelegate<UserContextMenu> {
}
