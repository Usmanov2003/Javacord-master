package org.javacord.api.event.server.emoji;

/**
 * A custom emoji create event.
 */
public interface KnownCustomEmojiCreateEvent extends KnownCustomEmojiEvent {
}
