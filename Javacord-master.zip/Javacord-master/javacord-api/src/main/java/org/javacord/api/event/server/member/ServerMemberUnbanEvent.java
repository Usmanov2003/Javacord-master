package org.javacord.api.event.server.member;

/**
 * A server member unban event.
 */
public interface ServerMemberUnbanEvent extends ServerMemberEvent {
}
