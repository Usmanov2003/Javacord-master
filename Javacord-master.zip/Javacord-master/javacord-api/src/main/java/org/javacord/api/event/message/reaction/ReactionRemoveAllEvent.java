package org.javacord.api.event.message.reaction;

/**
 * A reaction remove all event.
 */
public interface ReactionRemoveAllEvent extends ReactionEvent {
}
